'use client'

import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { Play, Pause, X, Volume2 } from 'lucide-react'
import type { Song } from '@/lib/types'
import { Slider } from '@/components/ui/slider'

interface MiniPlayerProps {
  song: Song | null
  isPlaying: boolean
  currentTime: number
  duration: number
  volume: number
  onTogglePlay: () => void
  onSeek: (time: number) => void
  onVolumeChange: (volume: number) => void
  onClose: () => void
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

export function MiniPlayer({
  song,
  isPlaying,
  currentTime,
  duration,
  volume,
  onTogglePlay,
  onSeek,
  onVolumeChange,
  onClose
}: MiniPlayerProps) {
  if (!song) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-0 left-0 right-0 z-40 p-4"
      >
        <div className="max-w-4xl mx-auto glass rounded-2xl p-4 shadow-2xl">
          <div className="flex items-center gap-4">
            {/* Album Art */}
            <div className="relative h-14 w-14 rounded-xl overflow-hidden flex-shrink-0">
              <Image
                src={song.coverImage || '/placeholder-album.jpg'}
                alt={song.title}
                fill
                className="object-cover"
              />
            </div>

            {/* Song Info */}
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-foreground truncate">{song.title}</h4>
              <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
            </div>

            {/* Progress */}
            <div className="hidden md:flex items-center gap-3 flex-1 max-w-md">
              <span className="text-xs text-muted-foreground w-10 text-right">
                {formatTime(currentTime)}
              </span>
              <Slider
                value={[currentTime]}
                max={duration || 100}
                step={1}
                onValueChange={([value]) => onSeek(value)}
                className="flex-1"
              />
              <span className="text-xs text-muted-foreground w-10">
                {formatTime(duration)}
              </span>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={onTogglePlay}
                className="h-12 w-12 rounded-full bg-primary flex items-center justify-center"
              >
                {isPlaying ? (
                  <Pause className="h-5 w-5 text-primary-foreground" fill="currentColor" />
                ) : (
                  <Play className="h-5 w-5 text-primary-foreground ml-0.5" fill="currentColor" />
                )}
              </motion.button>

              {/* Volume */}
              <div className="hidden md:flex items-center gap-2">
                <Volume2 className="h-4 w-4 text-muted-foreground" />
                <Slider
                  value={[volume * 100]}
                  max={100}
                  step={1}
                  onValueChange={([value]) => onVolumeChange(value / 100)}
                  className="w-20"
                />
              </div>

              <button
                onClick={onClose}
                className="p-2 rounded-xl hover:bg-muted transition-colors"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>
          </div>

          {/* Mobile Progress */}
          <div className="md:hidden mt-3">
            <Slider
              value={[currentTime]}
              max={duration || 100}
              step={1}
              onValueChange={([value]) => onSeek(value)}
              className="w-full"
            />
            <div className="flex justify-between mt-1">
              <span className="text-xs text-muted-foreground">{formatTime(currentTime)}</span>
              <span className="text-xs text-muted-foreground">{formatTime(duration)}</span>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}
