'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { Play, Pause, MoreVertical, Pencil, Trash2 } from 'lucide-react'
import type { Song } from '@/lib/types'
import { TagBadge } from '@/components/tag-badge'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface SongCardProps {
  song: Song
  isPlaying: boolean
  isCurrentSong: boolean
  onPlay: () => void
  onEdit: () => void
  onDelete: () => void
}

export function SongCard({ 
  song, 
  isPlaying, 
  isCurrentSong, 
  onPlay, 
  onEdit, 
  onDelete 
}: SongCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className={`group relative glass rounded-2xl p-4 flex items-center gap-4 transition-all ${
        isCurrentSong ? 'ring-2 ring-primary' : ''
      }`}
    >
      {/* Album Art */}
      <div className="relative h-16 w-16 rounded-xl overflow-hidden flex-shrink-0">
        <Image
          src={song.coverImage || '/placeholder-album.jpg'}
          alt={song.title}
          fill
          className="object-cover"
        />
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onPlay}
          className="absolute inset-0 flex items-center justify-center bg-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity"
        >
          {isPlaying && isCurrentSong ? (
            <Pause className="h-6 w-6 text-white" fill="currentColor" />
          ) : (
            <Play className="h-6 w-6 text-white" fill="currentColor" />
          )}
        </motion.button>
      </div>

      {/* Song Info */}
      <div className="flex-1 min-w-0">
        <h3 className="font-semibold text-foreground truncate">{song.title}</h3>
        <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
        <div className="flex flex-wrap gap-1 mt-2">
          {song.tags.slice(0, 3).map((tag) => (
            <TagBadge key={tag} tag={tag} />
          ))}
        </div>
      </div>

      {/* Actions */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button className="p-2 rounded-xl hover:bg-muted transition-colors opacity-0 group-hover:opacity-100">
            <MoreVertical className="h-5 w-5 text-muted-foreground" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="rounded-xl">
          <DropdownMenuItem onClick={onEdit} className="gap-2">
            <Pencil className="h-4 w-4" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onDelete} className="gap-2 text-destructive">
            <Trash2 className="h-4 w-4" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Playing indicator */}
      {isCurrentSong && isPlaying && (
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-1">
          <span className="w-1 h-3 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <span className="w-1 h-4 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <span className="w-1 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      )}
    </motion.div>
  )
}
