'use client'

import { useState, useRef, useEffect, useCallback } from 'react'
import type { Song } from '@/lib/types'

interface MusicPlayerState {
  currentSong: Song | null
  isPlaying: boolean
  currentTime: number
  duration: number
  volume: number
}

export function useMusicPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const [state, setState] = useState<MusicPlayerState>({
    currentSong: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 0.7
  })

  useEffect(() => {
    audioRef.current = new Audio()
    audioRef.current.volume = state.volume

    const audio = audioRef.current

    const handleTimeUpdate = () => {
      setState(prev => ({ ...prev, currentTime: audio.currentTime }))
    }

    const handleLoadedMetadata = () => {
      setState(prev => ({ ...prev, duration: audio.duration }))
    }

    const handleEnded = () => {
      setState(prev => ({ ...prev, isPlaying: false, currentTime: 0 }))
    }

    audio.addEventListener('timeupdate', handleTimeUpdate)
    audio.addEventListener('loadedmetadata', handleLoadedMetadata)
    audio.addEventListener('ended', handleEnded)

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate)
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata)
      audio.removeEventListener('ended', handleEnded)
      audio.pause()
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const playSong = useCallback((song: Song) => {
    if (audioRef.current) {
      if (state.currentSong?.id === song.id) {
        if (state.isPlaying) {
          audioRef.current.pause()
          setState(prev => ({ ...prev, isPlaying: false }))
        } else {
          audioRef.current.play()
          setState(prev => ({ ...prev, isPlaying: true }))
        }
      } else {
        audioRef.current.src = song.audioUrl || ''
        audioRef.current.play().catch(() => {
          // No audio URL - just update state
        })
        setState(prev => ({
          ...prev,
          currentSong: song,
          isPlaying: true,
          currentTime: 0
        }))
      }
    }
  }, [state.currentSong?.id, state.isPlaying])

  const togglePlay = useCallback(() => {
    if (audioRef.current && state.currentSong) {
      if (state.isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setState(prev => ({ ...prev, isPlaying: !prev.isPlaying }))
    }
  }, [state.currentSong, state.isPlaying])

  const seek = useCallback((time: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = time
      setState(prev => ({ ...prev, currentTime: time }))
    }
  }, [])

  const setVolume = useCallback((volume: number) => {
    if (audioRef.current) {
      audioRef.current.volume = volume
      setState(prev => ({ ...prev, volume }))
    }
  }, [])

  const stop = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.currentTime = 0
      setState(prev => ({
        ...prev,
        isPlaying: false,
        currentTime: 0,
        currentSong: null
      }))
    }
  }, [])

  return {
    ...state,
    playSong,
    togglePlay,
    seek,
    setVolume,
    stop
  }
}
