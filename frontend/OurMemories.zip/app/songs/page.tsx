'use client'

import { useState } from 'react'
import useSWR, { mutate } from 'swr'
import { motion } from 'framer-motion'
import { Music, Plus, Sparkles } from 'lucide-react'
import { Navbar } from '@/components/navbar'
import { PageHeader } from '@/components/page-header'
import { SongCard } from '@/components/songs/song-card'
import { MiniPlayer } from '@/components/songs/mini-player'
import { AddItemModal } from '@/components/add-item-modal'
import { EmptyState } from '@/components/empty-state'
import { TagBadge } from '@/components/tag-badge'
import { Button } from '@/components/ui/button'
import { useMusicPlayer } from '@/hooks/use-music-player'
import { getSimilarItems } from '@/lib/algorithms'
import type { Song } from '@/lib/types'
import { toast } from 'sonner'

const fetcher = (url: string) => fetch(url).then(res => res.json())

export default function SongsPage() {
  const { data: songs = [], isLoading } = useSWR<Song[]>('/api/songs', fetcher)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [editingSong, setEditingSong] = useState<Song | null>(null)
  
  const player = useMusicPlayer()

  const handleAddSong = async (data: Record<string, unknown>) => {
    const response = await fetch('/api/songs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: data.title,
        artist: data.artist,
        coverImage: data.coverImage,
        audioUrl: data.audioUrl,
        tags: data.tags
      })
    })
    
    if (response.ok) {
      mutate('/api/songs')
      toast.success('Song added successfully!')
    }
  }

  const handleDeleteSong = async (id: string) => {
    const response = await fetch(`/api/songs?id=${id}`, { method: 'DELETE' })
    if (response.ok) {
      mutate('/api/songs')
      toast.success('Song deleted')
    }
  }

  // Get similar songs for recommendations
  const recommendations = player.currentSong 
    ? getSimilarItems(player.currentSong, songs, 3)
    : []

  return (
    <div className="min-h-screen gradient-soft">
      <Navbar />
      
      <main className="container mx-auto px-4 pt-32 pb-32">
        <PageHeader 
          title="Our Favorite Songs"
          subtitle="The soundtrack of our love story"
          icon={Music}
        />

        {/* Add Button */}
        <div className="flex justify-center mb-8">
          <Button 
            onClick={() => setIsModalOpen(true)}
            className="rounded-xl gap-2"
          >
            <Plus className="h-4 w-4" />
            Add Song
          </Button>
        </div>

        {isLoading ? (
          <div className="grid gap-4 max-w-2xl mx-auto">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-2xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : songs.length === 0 ? (
          <EmptyState
            icon={Music}
            title="No songs yet"
            description="Start building your playlist by adding your favorite songs"
            actionLabel="Add First Song"
            onAction={() => setIsModalOpen(true)}
          />
        ) : (
          <div className="grid gap-4 max-w-2xl mx-auto">
            {songs.map((song, index) => (
              <motion.div
                key={song.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <SongCard
                  song={song}
                  isPlaying={player.isPlaying}
                  isCurrentSong={player.currentSong?.id === song.id}
                  onPlay={() => player.playSong(song)}
                  onEdit={() => setEditingSong(song)}
                  onDelete={() => handleDeleteSong(song.id)}
                />
              </motion.div>
            ))}
          </div>
        )}

        {/* Recommendations Section */}
        {recommendations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-12 max-w-2xl mx-auto"
          >
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-semibold text-foreground">You may also like</h2>
            </div>
            <div className="grid gap-3">
              {recommendations.map((song) => (
                <div
                  key={song.id}
                  className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                  onClick={() => player.playSong(song)}
                >
                  <div className="h-10 w-10 rounded-lg overflow-hidden">
                    <img
                      src={song.coverImage}
                      alt={song.title}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate">{song.title}</p>
                    <p className="text-sm text-muted-foreground truncate">{song.artist}</p>
                  </div>
                  <div className="flex gap-1">
                    {song.tags.slice(0, 2).map((tag) => (
                      <TagBadge key={tag} tag={tag} />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </main>

      {/* Mini Player */}
      <MiniPlayer
        song={player.currentSong}
        isPlaying={player.isPlaying}
        currentTime={player.currentTime}
        duration={player.duration}
        volume={player.volume}
        onTogglePlay={player.togglePlay}
        onSeek={player.seek}
        onVolumeChange={player.setVolume}
        onClose={player.stop}
      />

      {/* Add Song Modal */}
      <AddItemModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleAddSong}
        title="Add New Song"
        fields={[
          { name: 'title', label: 'Song Title', type: 'text', placeholder: 'Enter song title', required: true },
          { name: 'artist', label: 'Artist', type: 'text', placeholder: 'Enter artist name', required: true },
          { name: 'coverImage', label: 'Cover Image URL', type: 'url', placeholder: 'https://...' },
          { name: 'audioUrl', label: 'Audio URL (optional)', type: 'url', placeholder: 'https://...' }
        ]}
        tagType="mood"
      />

      {/* Edit Song Modal - would be similar structure */}
      {editingSong && (
        <AddItemModal
          isOpen={!!editingSong}
          onClose={() => setEditingSong(null)}
          onSubmit={async (data) => {
            await fetch('/api/songs', {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: editingSong.id, ...data })
            })
            mutate('/api/songs')
            setEditingSong(null)
            toast.success('Song updated!')
          }}
          title="Edit Song"
          fields={[
            { name: 'title', label: 'Song Title', type: 'text', placeholder: editingSong.title },
            { name: 'artist', label: 'Artist', type: 'text', placeholder: editingSong.artist },
            { name: 'coverImage', label: 'Cover Image URL', type: 'url', placeholder: editingSong.coverImage },
            { name: 'audioUrl', label: 'Audio URL', type: 'url', placeholder: editingSong.audioUrl || '' }
          ]}
          tagType="mood"
        />
      )}
    </div>
  )
}
