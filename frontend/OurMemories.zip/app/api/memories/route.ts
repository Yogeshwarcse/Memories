import { NextResponse } from 'next/server'
import { getMemories, addMemory, updateMemory, deleteMemory } from '@/lib/store'
import { v4 as uuidv4 } from 'uuid'
import type { Memory } from '@/lib/types'

export async function GET() {
  const memories = getMemories()
  return NextResponse.json(memories)
}

export async function POST(request: Request) {
  const body = await request.json()
  const memory: Memory = {
    id: uuidv4(),
    image: body.image || '',
    description: body.description || '',
    date: body.date || new Date().toISOString().split('T')[0],
    tags: body.tags || [],
    createdAt: new Date().toISOString()
  }
  addMemory(memory)
  return NextResponse.json(memory, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  updateMemory(body.id, body)
  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (id) {
    deleteMemory(id)
    return NextResponse.json({ success: true })
  }
  return NextResponse.json({ error: 'ID required' }, { status: 400 })
}
