import { NextResponse } from 'next/server'
import { getSnaps, addSnap, updateSnap, deleteSnap } from '@/lib/store'
import { v4 as uuidv4 } from 'uuid'
import type { Snap } from '@/lib/types'

export async function GET() {
  const snaps = getSnaps()
  return NextResponse.json(snaps)
}

export async function POST(request: Request) {
  const body = await request.json()
  const snap: Snap = {
    id: uuidv4(),
    image: body.image || '',
    description: body.description || '',
    tags: body.tags || [],
    createdAt: new Date().toISOString()
  }
  addSnap(snap)
  return NextResponse.json(snap, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  updateSnap(body.id, body)
  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (id) {
    deleteSnap(id)
    return NextResponse.json({ success: true })
  }
  return NextResponse.json({ error: 'ID required' }, { status: 400 })
}
