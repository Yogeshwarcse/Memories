import { NextResponse } from 'next/server'
import { getFavoriteThings, addFavoriteThing, updateFavoriteThing, deleteFavoriteThing } from '@/lib/store'
import { v4 as uuidv4 } from 'uuid'
import type { FavoriteThing } from '@/lib/types'

export async function GET() {
  const things = getFavoriteThings()
  return NextResponse.json(things)
}

export async function POST(request: Request) {
  const body = await request.json()
  const thing: FavoriteThing = {
    id: uuidv4(),
    image: body.image || '',
    description: body.description || '',
    tags: body.tags || [],
    createdAt: new Date().toISOString()
  }
  addFavoriteThing(thing)
  return NextResponse.json(thing, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  updateFavoriteThing(body.id, body)
  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (id) {
    deleteFavoriteThing(id)
    return NextResponse.json({ success: true })
  }
  return NextResponse.json({ error: 'ID required' }, { status: 400 })
}
