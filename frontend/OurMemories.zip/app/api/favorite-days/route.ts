import { NextResponse } from 'next/server'
import { getFavoriteDays, addFavoriteDay, updateFavoriteDay, deleteFavoriteDay } from '@/lib/store'
import { v4 as uuidv4 } from 'uuid'
import type { FavoriteDay } from '@/lib/types'

export async function GET() {
  const days = getFavoriteDays()
  return NextResponse.json(days)
}

export async function POST(request: Request) {
  const body = await request.json()
  const day: FavoriteDay = {
    id: uuidv4(),
    date: body.date,
    image: body.image || '',
    description: body.description || '',
    tags: body.tags || [],
    createdAt: new Date().toISOString()
  }
  addFavoriteDay(day)
  return NextResponse.json(day, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  updateFavoriteDay(body.id, body)
  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (id) {
    deleteFavoriteDay(id)
    return NextResponse.json({ success: true })
  }
  return NextResponse.json({ error: 'ID required' }, { status: 400 })
}
