import { NextResponse } from 'next/server'
import { getSongs, addSong, updateSong, deleteSong } from '@/lib/store'
import { v4 as uuidv4 } from 'uuid'
import type { Song } from '@/lib/types'

export async function GET() {
  const songs = getSongs()
  return NextResponse.json(songs)
}

export async function POST(request: Request) {
  const body = await request.json()
  const song: Song = {
    id: uuidv4(),
    title: body.title,
    artist: body.artist,
    coverImage: body.coverImage || '',
    audioUrl: body.audioUrl || '',
    tags: body.tags || [],
    createdAt: new Date().toISOString()
  }
  addSong(song)
  return NextResponse.json(song, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  updateSong(body.id, body)
  return NextResponse.json({ success: true })
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')
  if (id) {
    deleteSong(id)
    return NextResponse.json({ success: true })
  }
  return NextResponse.json({ error: 'ID required' }, { status: 400 })
}
