import type { Song, FavoriteDay, Snap, Memory, FavoriteThing } from './types'

// In-memory store for demo purposes
// In production, this would connect to MongoDB

interface Store {
  songs: Song[]
  favoriteDays: FavoriteDay[]
  snaps: Snap[]
  memories: Memory[]
  favoriteThings: FavoriteThing[]
}

const store: Store = {
  songs: [
    {
      id: '1',
      title: 'Perfect',
      artist: 'Ed Sheeran',
      coverImage: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=300&fit=crop',
      audioUrl: '',
      tags: ['romantic', 'love', 'slow'],
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      title: 'Happy',
      artist: 'Pharrell Williams',
      coverImage: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=300&h=300&fit=crop',
      audioUrl: '',
      tags: ['happy', 'energetic', 'fun'],
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      title: 'Thinking Out Loud',
      artist: 'Ed Sheeran',
      coverImage: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=300&h=300&fit=crop',
      audioUrl: '',
      tags: ['romantic', 'slow', 'love'],
      createdAt: new Date().toISOString()
    }
  ],
  favoriteDays: [
    {
      id: '1',
      date: '2024-02-14',
      image: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=600&h=400&fit=crop',
      description: 'Our first Valentine\'s Day together. We had dinner at that cozy Italian restaurant downtown.',
      tags: ['romantic', 'celebration', 'love'],
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      date: '2024-06-15',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&h=400&fit=crop',
      description: 'Beach trip with friends. The sunset was absolutely magical!',
      tags: ['trip', 'friends', 'nature'],
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      date: '2024-08-20',
      image: 'https://images.unsplash.com/photo-1464349153159-9e7f46e8f6d0?w=600&h=400&fit=crop',
      description: 'Hiking adventure in the mountains. The view from the top was breathtaking.',
      tags: ['adventure', 'nature', 'fun'],
      createdAt: new Date().toISOString()
    }
  ],
  snaps: [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=600&fit=crop',
      description: 'Squad goals!',
      tags: ['friends', 'fun'],
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=600&h=600&fit=crop',
      description: 'Us being silly',
      tags: ['love', 'fun'],
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?w=600&h=600&fit=crop',
      description: 'Coffee date mornings',
      tags: ['cozy', 'love'],
      createdAt: new Date().toISOString()
    },
    {
      id: '4',
      image: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?w=600&h=600&fit=crop',
      description: 'Adventure awaits',
      tags: ['trip', 'adventure'],
      createdAt: new Date().toISOString()
    }
  ],
  memories: [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1522748906645-95d8adfd52c7?w=600&h=400&fit=crop',
      description: 'The day we met - it feels like yesterday. I still remember how nervous I was, but the moment our eyes met, everything felt right.',
      date: '2023-09-15',
      tags: ['love', 'special'],
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1469371670807-013ccf25f16a?w=600&h=400&fit=crop',
      description: 'Our anniversary dinner. You surprised me with flowers and that beautiful handwritten letter. I cried happy tears.',
      date: '2024-09-15',
      tags: ['celebration', 'romantic', 'love'],
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1530789253388-582c481c54b0?w=600&h=400&fit=crop',
      description: 'Road trip across the coast. We got lost twice but found the most amazing hidden beach.',
      date: '2024-07-20',
      tags: ['trip', 'adventure', 'fun'],
      createdAt: new Date().toISOString()
    }
  ],
  favoriteThings: [
    {
      id: '1',
      image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=400&h=400&fit=crop',
      description: 'Morning coffee together',
      tags: ['cozy', 'love'],
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=400&fit=crop',
      description: 'Our favorite pasta dish',
      tags: ['food', 'love'],
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      image: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=400&h=400&fit=crop',
      description: 'Our cozy reading nook',
      tags: ['cozy', 'special'],
      createdAt: new Date().toISOString()
    },
    {
      id: '4',
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop',
      description: 'Matching sneakers',
      tags: ['fun', 'love'],
      createdAt: new Date().toISOString()
    }
  ]
}

// Export the store and helper functions
export const getStore = () => store

export const getSongs = () => store.songs
export const addSong = (song: Song) => { store.songs.push(song) }
export const updateSong = (id: string, data: Partial<Song>) => {
  const index = store.songs.findIndex(s => s.id === id)
  if (index !== -1) store.songs[index] = { ...store.songs[index], ...data }
}
export const deleteSong = (id: string) => {
  store.songs = store.songs.filter(s => s.id !== id)
}

export const getFavoriteDays = () => store.favoriteDays
export const addFavoriteDay = (day: FavoriteDay) => { store.favoriteDays.push(day) }
export const updateFavoriteDay = (id: string, data: Partial<FavoriteDay>) => {
  const index = store.favoriteDays.findIndex(d => d.id === id)
  if (index !== -1) store.favoriteDays[index] = { ...store.favoriteDays[index], ...data }
}
export const deleteFavoriteDay = (id: string) => {
  store.favoriteDays = store.favoriteDays.filter(d => d.id !== id)
}

export const getSnaps = () => store.snaps
export const addSnap = (snap: Snap) => { store.snaps.push(snap) }
export const updateSnap = (id: string, data: Partial<Snap>) => {
  const index = store.snaps.findIndex(s => s.id === id)
  if (index !== -1) store.snaps[index] = { ...store.snaps[index], ...data }
}
export const deleteSnap = (id: string) => {
  store.snaps = store.snaps.filter(s => s.id !== id)
}

export const getMemories = () => store.memories
export const addMemory = (memory: Memory) => { store.memories.push(memory) }
export const updateMemory = (id: string, data: Partial<Memory>) => {
  const index = store.memories.findIndex(m => m.id === id)
  if (index !== -1) store.memories[index] = { ...store.memories[index], ...data }
}
export const deleteMemory = (id: string) => {
  store.memories = store.memories.filter(m => m.id !== id)
}

export const getFavoriteThings = () => store.favoriteThings
export const addFavoriteThing = (thing: FavoriteThing) => { store.favoriteThings.push(thing) }
export const updateFavoriteThing = (id: string, data: Partial<FavoriteThing>) => {
  const index = store.favoriteThings.findIndex(t => t.id === id)
  if (index !== -1) store.favoriteThings[index] = { ...store.favoriteThings[index], ...data }
}
export const deleteFavoriteThing = (id: string) => {
  store.favoriteThings = store.favoriteThings.filter(t => t.id !== id)
}
