export interface Song {
  id: string
  title: string
  artist: string
  coverImage: string
  audioUrl: string
  tags: string[]
  createdAt: string
}

export interface FavoriteDay {
  id: string
  date: string
  image: string
  description: string
  tags: string[]
  createdAt: string
}

export interface Snap {
  id: string
  image: string
  description: string
  tags: string[]
  createdAt: string
}

export interface Memory {
  id: string
  image: string
  description: string
  date: string
  tags: string[]
  createdAt: string
}

export interface FavoriteThing {
  id: string
  image: string
  description: string
  tags: string[]
  createdAt: string
}

export type MoodTag = 'happy' | 'romantic' | 'sad' | 'nostalgic' | 'peaceful' | 'energetic' | 'fun' | 'love'

export const MOOD_TAGS: MoodTag[] = ['happy', 'romantic', 'sad', 'nostalgic', 'peaceful', 'energetic', 'fun', 'love']

export const CATEGORY_TAGS = ['trip', 'friends', 'family', 'food', 'nature', 'celebration', 'adventure', 'cozy', 'special']
